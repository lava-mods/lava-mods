package com.example.risinglava;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;

public class ActiveLavaRegion {
    private final BlockPos center;
    private final int radius;
    private int currentHeight;
    private boolean isActive;

    public ActiveLavaRegion(BlockPos centerPos, int regionRadius, int startHeight) {
        this.center = centerPos;
        this.radius = regionRadius;
        // 从起始高度下方开始，确保第一次rise能到达起始高度
        this.currentHeight = startHeight - 1;
        this.isActive = true;
    }

    // 让岩浆上升一格并生成新的岩浆层
    public void riseLava(World world) {
        currentHeight++;
        generateLavaLayer(world, currentHeight);
    }

    // 在指定高度生成一整层岩浆
    private void generateLavaLayer(World world, int yLevel) {
        // 以中心为原点，在半径范围内生成岩浆
        for (int x = -radius; x <= radius; x++) {
            // 提前计算x平方，优化性能
            int xSquared = x * x;
            for (int z = -radius; z <= radius; z++) {
                // 检查是否在圆形范围内（优化性能，避免生成方形区域）
                if (xSquared + z * z <= radius * radius) {
                    BlockPos pos = new BlockPos(center.getX() + x, yLevel, center.getZ() + z);
                    
                    // 只替换空气方块为岩浆，保留其他方块
                    if (world.isAirBlock(pos)) {
                        world.setBlockState(pos, Blocks.LAVA.getDefaultState());
                    }
                }
            }
        }
    }

    public int getCurrentHeight() {
        return currentHeight;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
    