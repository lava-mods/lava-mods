package com.example.risinglava;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = RisingLava.MOD_ID)
public class LavaRiseManager {
    private static LavaRiseManager instance;
    private final List<ActiveLavaRegion> activeRegions = new ArrayList<>();
    private int tickCounter = 0;
    // 每分钟上升一格 (20 ticks = 1秒, 60秒 = 1200 ticks)
    private final int riseInterval = 1200;
    private boolean hasStarted = false;
    
    // 世界高度范围 (1.18+ 版本)
    private static final int WORLD_MIN_Y = -64;
    private static final int WORLD_MAX_Y = 320;

    private LavaRiseManager() {}

    // 单例模式获取实例
    public static synchronized LavaRiseManager getInstance() {
        if (instance == null) {
            instance = new LavaRiseManager();
        }
        return instance;
    }

    // 世界tick事件监听
    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        // 只在服务端和世界tick结束阶段运行
        if (event.phase != TickEvent.Phase.END || event.world.isRemote) {
            return;
        }

        World world = event.world;
        
        // 首次加载时自动创建全局岩浆区域
        if (!hasStarted) {
            startGlobalLavaRegion(world);
            hasStarted = true;
        }

        tickCounter++;
        // 达到间隔时间时让岩浆上升
        if (tickCounter >= riseInterval) {
            tickCounter = 0;
            riseAllLavaRegions(world);
        }
    }

    // 创建覆盖全局的岩浆区域
    private void startGlobalLavaRegion(World world) {
        // 以世界原点为中心
        BlockPos centerPos = new BlockPos(0, 0, 0);
        // 大半径以覆盖大部分世界
        int radius = 2000;
        // 从世界最底部开始
        ActiveLavaRegion region = new ActiveLavaRegion(centerPos, radius, WORLD_MIN_Y);
        activeRegions.add(region);
        
        // 初始生成第一格高度的岩浆
        region.riseLava(world);
    }

    // 让所有活跃的岩浆区域上升
    private void riseAllLavaRegions(World world) {
        for (int i = activeRegions.size() - 1; i >= 0; i--) {
            ActiveLavaRegion region = activeRegions.get(i);
            // 检查是否已达到世界最高处
            if (region.getCurrentHeight() < WORLD_MAX_Y && region.isActive()) {
                region.riseLava(world);
            } else {
                region.setActive(false);
                activeRegions.remove(i);
            }
        }
    }
}
    