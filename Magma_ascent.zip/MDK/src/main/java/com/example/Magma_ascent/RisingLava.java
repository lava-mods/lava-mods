package com.example.risinglava;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(RisingLava.MOD_ID)
public class RisingLava {
    public static final String MOD_ID = "risinglava";

    public RisingLava() {
        // 注册事件总线
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(LavaRiseManager.getInstance());
    }
}
    